# MCP Servers Dotfiles

MCP (Model Context Protocol) servers for use with Claude Code in GitHub Codespaces.

## Included Servers

### Athena MCP
Query AWS Athena databases directly from Claude Code.

**Tools available:**
- `athena_query` - Execute SQL queries
- `athena_list_databases` - List available databases
- `athena_list_tables` - List tables in a database
- `athena_describe_table` - Get table schema
- `athena_sample_query` - Quick sample from bid_pricer_log

### Slack MCP
Interact with Slack channels from Claude Code.

**Tools available:**
- `slack_list_channels` - List accessible channels
- `slack_read_messages` - Read messages from a channel
- `slack_send_message` - Send a message to a channel
- `slack_delete_message` - Delete a message

## Setup

### Automatic Setup (Codespaces Dotfiles)

1. Go to [GitHub Settings > Codespaces](https://github.com/settings/codespaces)
2. Under "Dotfiles", check "Automatically install dotfiles"
3. Select this repository (`dotfiles-mcp`)
4. New codespaces will automatically run `install.sh`

### Manual Setup

```bash
git clone https://github.com/VoodooTeam/dotfiles-mcp.git ~/dotfiles-mcp
cd ~/dotfiles-mcp
./install.sh
```

## Usage

After setup, copy the config template to any project:

```bash
cp ~/dotfiles-mcp/mcp-config-template.json /path/to/project/.mcp.json
```

Then run `claude` in that project directory.

## Environment Variables

### Athena
- `AWS_PROFILE_NAME` - AWS SSO profile name (default: `voodoo-adn-prod`)
- `AWS_REGION_NAME` - AWS region (default: `eu-west-1`)

### Slack
- `SLACK_BOT_TOKEN` - Slack bot token (set in Codespaces secrets)
- `SLACK_CHANNEL_ALLOWLIST` - Comma-separated list of allowed channel IDs (optional)

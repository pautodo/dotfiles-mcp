#!/bin/bash
# Codespaces automatically runs this script after cloning dotfiles repo
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Setting up MCP servers from dotfiles..."

# Setup Athena MCP
if [ -d "$SCRIPT_DIR/athena-mcp" ]; then
    echo "Setting up Athena MCP server..."
    cd "$SCRIPT_DIR/athena-mcp"
    ./setup.sh
fi

# Setup Slack MCP
if [ -d "$SCRIPT_DIR/slack-mcp" ]; then
    echo "Setting up Slack MCP server..."
    cd "$SCRIPT_DIR/slack-mcp"
    ./setup.sh
fi

echo ""
echo "MCP servers setup complete!"
echo "To use in a project, copy the config template:"
echo "  cp ~/dotfiles-mcp/mcp-config-template.json /path/to/project/.mcp.json"
